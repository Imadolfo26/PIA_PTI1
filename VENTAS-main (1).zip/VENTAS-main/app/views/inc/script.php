<script src="<?php echo APP_URL; ?>app/views/js/ajax.js" ></script>
<script src="<?php echo APP_URL; ?>app/views/js/main.js" ></script>